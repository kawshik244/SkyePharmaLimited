package javaswingdev;

public interface MenuEvent {

    public void selected(int index, int subIndex, boolean menuItem);
}
